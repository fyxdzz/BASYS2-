/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/yun/Desktop/FPGA/paixu/paixu_verilog.v";



static int sp_paixu(char *t1, char *t2)
{
    char t11[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 848);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(38, ng0);
    t5 = (t1 + 3640);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t1 + 3800);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memset(t11, 0, 8);
    t12 = (t7 + 4);
    if (*((unsigned int *)t12) != 0)
        goto LAB6;

LAB5:    t13 = (t10 + 4);
    if (*((unsigned int *)t13) != 0)
        goto LAB6;

LAB9:    if (*((unsigned int *)t7) > *((unsigned int *)t10))
        goto LAB7;

LAB8:    t15 = (t11 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (~(t16));
    t18 = *((unsigned int *)t11);
    t19 = (t18 & t17);
    t20 = (t19 != 0);
    if (t20 > 0)
        goto LAB10;

LAB11:
LAB12:
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB6:    t14 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t14) = 1;
    goto LAB8;

LAB7:    *((unsigned int *)t11) = 1;
    goto LAB8;

LAB10:    xsi_set_current_line(38, ng0);

LAB13:    xsi_set_current_line(39, ng0);
    t21 = (t1 + 3640);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t1 + 3960);
    xsi_vlogvar_assign_value(t24, t23, 0, 0, 2);
    xsi_set_current_line(40, ng0);
    t4 = (t1 + 3800);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3640);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 2);
    xsi_set_current_line(41, ng0);
    t4 = (t1 + 3960);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3800);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 2);
    goto LAB12;

}

static void Always_26_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;

LAB0:    t1 = (t0 + 4880U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(26, ng0);
    t2 = (t0 + 5200);
    *((int *)t2) = 1;
    t3 = (t0 + 4912);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(26, ng0);

LAB5:    xsi_set_current_line(27, ng0);
    t5 = (t0 + 1960U);
    t6 = *((char **)t5);
    t5 = (t0 + 1800U);
    t7 = *((char **)t5);
    t5 = (t0 + 1640U);
    t8 = *((char **)t5);
    t5 = (t0 + 1480U);
    t9 = *((char **)t5);
    xsi_vlogtype_concat(t4, 8, 8, 4U, t9, 2, t8, 2, t7, 2, t6, 2);
    t5 = (t0 + 3480);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 2);
    t10 = (t0 + 3320);
    xsi_vlogvar_assign_value(t10, t4, 2, 0, 2);
    t11 = (t0 + 3160);
    xsi_vlogvar_assign_value(t11, t4, 4, 0, 2);
    t12 = (t0 + 3000);
    xsi_vlogvar_assign_value(t12, t4, 6, 0, 2);
    xsi_set_current_line(28, ng0);
    t2 = (t0 + 3000);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 3480);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 4688);
    t10 = (t0 + 848);
    t11 = xsi_create_subprogram_invocation(t9, 0, t0, t10, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t10, t11);
    t12 = (t0 + 3640);
    xsi_vlogvar_assign_value(t12, t5, 0, 0, 2);
    t13 = (t0 + 3800);
    xsi_vlogvar_assign_value(t13, t8, 0, 0, 2);

LAB8:    t14 = (t0 + 4784);
    t15 = *((char **)t14);
    t16 = (t15 + 80U);
    t17 = *((char **)t16);
    t18 = (t17 + 272U);
    t19 = *((char **)t18);
    t20 = (t19 + 0U);
    t21 = *((char **)t20);
    t22 = ((int  (*)(char *, char *))t21)(t0, t15);

LAB10:    if (t22 != 0)
        goto LAB11;

LAB6:    t15 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t15);

LAB7:    t23 = (t0 + 4784);
    t24 = *((char **)t23);
    t23 = (t0 + 3640);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t0 + 3000);
    xsi_vlogvar_assign_value(t27, t26, 0, 0, 2);
    t28 = (t0 + 3800);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t0 + 3480);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 2);
    t32 = (t0 + 848);
    t33 = (t0 + 4688);
    t34 = 0;
    xsi_delete_subprogram_invocation(t32, t24, t0, t33, t34);
    xsi_set_current_line(29, ng0);
    t2 = (t0 + 3160);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 3320);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 4688);
    t10 = (t0 + 848);
    t11 = xsi_create_subprogram_invocation(t9, 0, t0, t10, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t10, t11);
    t12 = (t0 + 3640);
    xsi_vlogvar_assign_value(t12, t5, 0, 0, 2);
    t13 = (t0 + 3800);
    xsi_vlogvar_assign_value(t13, t8, 0, 0, 2);

LAB14:    t14 = (t0 + 4784);
    t15 = *((char **)t14);
    t16 = (t15 + 80U);
    t17 = *((char **)t16);
    t18 = (t17 + 272U);
    t19 = *((char **)t18);
    t20 = (t19 + 0U);
    t21 = *((char **)t20);
    t22 = ((int  (*)(char *, char *))t21)(t0, t15);

LAB16:    if (t22 != 0)
        goto LAB17;

LAB12:    t15 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t15);

LAB13:    t23 = (t0 + 4784);
    t24 = *((char **)t23);
    t23 = (t0 + 3640);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t0 + 3160);
    xsi_vlogvar_assign_value(t27, t26, 0, 0, 2);
    t28 = (t0 + 3800);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t0 + 3320);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 2);
    t32 = (t0 + 848);
    t33 = (t0 + 4688);
    t34 = 0;
    xsi_delete_subprogram_invocation(t32, t24, t0, t33, t34);
    xsi_set_current_line(30, ng0);
    t2 = (t0 + 3000);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 3160);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 4688);
    t10 = (t0 + 848);
    t11 = xsi_create_subprogram_invocation(t9, 0, t0, t10, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t10, t11);
    t12 = (t0 + 3640);
    xsi_vlogvar_assign_value(t12, t5, 0, 0, 2);
    t13 = (t0 + 3800);
    xsi_vlogvar_assign_value(t13, t8, 0, 0, 2);

LAB20:    t14 = (t0 + 4784);
    t15 = *((char **)t14);
    t16 = (t15 + 80U);
    t17 = *((char **)t16);
    t18 = (t17 + 272U);
    t19 = *((char **)t18);
    t20 = (t19 + 0U);
    t21 = *((char **)t20);
    t22 = ((int  (*)(char *, char *))t21)(t0, t15);

LAB22:    if (t22 != 0)
        goto LAB23;

LAB18:    t15 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t15);

LAB19:    t23 = (t0 + 4784);
    t24 = *((char **)t23);
    t23 = (t0 + 3640);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t0 + 3000);
    xsi_vlogvar_assign_value(t27, t26, 0, 0, 2);
    t28 = (t0 + 3800);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t0 + 3160);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 2);
    t32 = (t0 + 848);
    t33 = (t0 + 4688);
    t34 = 0;
    xsi_delete_subprogram_invocation(t32, t24, t0, t33, t34);
    xsi_set_current_line(31, ng0);
    t2 = (t0 + 3320);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 3480);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 4688);
    t10 = (t0 + 848);
    t11 = xsi_create_subprogram_invocation(t9, 0, t0, t10, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t10, t11);
    t12 = (t0 + 3640);
    xsi_vlogvar_assign_value(t12, t5, 0, 0, 2);
    t13 = (t0 + 3800);
    xsi_vlogvar_assign_value(t13, t8, 0, 0, 2);

LAB26:    t14 = (t0 + 4784);
    t15 = *((char **)t14);
    t16 = (t15 + 80U);
    t17 = *((char **)t16);
    t18 = (t17 + 272U);
    t19 = *((char **)t18);
    t20 = (t19 + 0U);
    t21 = *((char **)t20);
    t22 = ((int  (*)(char *, char *))t21)(t0, t15);

LAB28:    if (t22 != 0)
        goto LAB29;

LAB24:    t15 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t15);

LAB25:    t23 = (t0 + 4784);
    t24 = *((char **)t23);
    t23 = (t0 + 3640);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t0 + 3320);
    xsi_vlogvar_assign_value(t27, t26, 0, 0, 2);
    t28 = (t0 + 3800);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t0 + 3480);
    xsi_vlogvar_assign_value(t31, t30, 0, 0, 2);
    t32 = (t0 + 848);
    t33 = (t0 + 4688);
    t34 = 0;
    xsi_delete_subprogram_invocation(t32, t24, t0, t33, t34);
    xsi_set_current_line(32, ng0);
    t2 = (t0 + 3480);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t6 = (t0 + 3320);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t0 + 3160);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t0 + 3000);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    xsi_vlogtype_concat(t4, 8, 8, 4U, t14, 2, t11, 2, t8, 2, t5, 2);
    t15 = (t0 + 2840);
    xsi_vlogvar_assign_value(t15, t4, 0, 0, 2);
    t16 = (t0 + 2680);
    xsi_vlogvar_assign_value(t16, t4, 2, 0, 2);
    t17 = (t0 + 2520);
    xsi_vlogvar_assign_value(t17, t4, 4, 0, 2);
    t18 = (t0 + 2360);
    xsi_vlogvar_assign_value(t18, t4, 6, 0, 2);
    goto LAB2;

LAB9:;
LAB11:    t14 = (t0 + 4880U);
    *((char **)t14) = &&LAB8;
    goto LAB1;

LAB15:;
LAB17:    t14 = (t0 + 4880U);
    *((char **)t14) = &&LAB14;
    goto LAB1;

LAB21:;
LAB23:    t14 = (t0 + 4880U);
    *((char **)t14) = &&LAB20;
    goto LAB1;

LAB27:;
LAB29:    t14 = (t0 + 4880U);
    *((char **)t14) = &&LAB26;
    goto LAB1;

}


extern void work_m_00000000003859754753_3571054517_init()
{
	static char *pe[] = {(void *)Always_26_0};
	static char *se[] = {(void *)sp_paixu};
	xsi_register_didat("work_m_00000000003859754753_3571054517", "isim/paixu_test_isim_beh.exe.sim/work/m_00000000003859754753_3571054517.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
